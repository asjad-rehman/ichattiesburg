// ich-app.jsx — App root with routing

const ZEFFY_ONE_TIME = 'https://www.zeffy.com/donation-form/ba0c6cb0-70a2-41db-95c6-9ff75a30b42c';
const ZEFFY_MONTHLY  = 'https://www.zeffy.com/donation-form/e4338258-eef5-489e-ae60-75017200e9bc';

function DonatePage({ setPage }) {
  const [type, setType] = React.useState('one-time');
  return (
    <div className="page-enter" style={{ maxWidth:760, margin:'0 auto', padding:'52px 24px 80px' }}>

      <div style={{ marginBottom:40 }}>
        <GoldLabel>Support ICH</GoldLabel>
        <h1 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:'clamp(32px,5vw,52px)', fontWeight:600, marginBottom:12 }}>Donate</h1>
        <div className="amiri" style={{ fontSize:22, color:ICH.primary, marginBottom:8, direction:'rtl', lineHeight:1.9 }}>
          مَّن ذَا الَّذِي يُقْرِضُ اللَّهَ قَرْضًا حَسَنًا
        </div>
        <p style={{ fontSize:13, color:ICH.textMuted, fontStyle:'italic', marginBottom:16 }}>"Who is it that would loan Allah a goodly loan?" — Quran 2:245</p>
        <p style={{ fontSize:15, color:ICH.textMuted, lineHeight:1.75 }}>Your generosity supports our daily operations, new masjid project, Islamic education, and community programs. 100% of donations go directly to ICH.</p>
      </div>

      {/* One-time / Monthly toggle */}
      <div style={{ display:'flex', marginBottom:32, border:`1px solid ${ICH.border}`, borderRadius:6, overflow:'hidden', maxWidth:360 }}>
        {[['one-time','One-Time'],['monthly','Monthly']].map(([val, label]) => (
          <button key={val} onClick={() => setType(val)} style={{
            flex:1, padding:'12px 16px', border:'none', cursor:'pointer',
            background: type === val ? ICH.primary : '#fff',
            color: type === val ? '#fff' : ICH.textMuted,
            fontFamily:'Inter,sans-serif', fontSize:13, fontWeight:600, transition:'all .15s',
            borderRight: val === 'one-time' ? `1px solid ${ICH.border}` : 'none',
          }}>{label}</button>
        ))}
      </div>

      {/* Categories */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:12, marginBottom:36 }}>
        {[
          { title:'General Sadaqah', desc:'Day-to-day masjid operations',  icon:'🕌' },
          { title:'Zakat',           desc:'Fulfill your obligatory zakat', icon:'🤲' },
          { title:'New Masjid',      desc:'Build our permanent facility',  icon:'🏗️' },
          { title:'Quran Programs',  desc:'Islamic education for all ages',icon:'📖' },
        ].map(cat => (
          <div key={cat.title}
            style={{ padding:'18px 14px', background:'#fff', border:`1px solid ${ICH.border}`, borderRadius:6, cursor:'pointer', transition:'all .18s', textAlign:'center' }}
            onMouseEnter={e => { e.currentTarget.style.borderColor=ICH.gold; e.currentTarget.style.boxShadow='0 4px 16px rgba(200,169,110,.15)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor=ICH.border; e.currentTarget.style.boxShadow='none'; }}>
            <div style={{ fontSize:26, marginBottom:8 }}>{cat.icon}</div>
            <div style={{ fontFamily:'Cormorant Garamond,serif', fontSize:17, fontWeight:600, marginBottom:3 }}>{cat.title}</div>
            <div style={{ fontSize:11, color:ICH.textMuted, lineHeight:1.55 }}>{cat.desc}</div>
          </div>
        ))}
      </div>

      {/* Zeffy CTA */}
      <div style={{ background:`linear-gradient(135deg,${ICH.primaryDark},${ICH.primary})`, borderRadius:8, padding:'36px 40px', textAlign:'center', position:'relative', overflow:'hidden' }}>
        <div className="geo-bg" style={{ position:'absolute', inset:0, opacity:.5 }}/>
        <div style={{ position:'relative' }}>
          <div style={{ fontSize:12, fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', color:ICH.gold, fontFamily:'Inter,sans-serif', marginBottom:12 }}>
            {type === 'monthly' ? '🔄 Monthly Giving' : '♥ One-Time Gift'}
          </div>
          <h2 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:28, color:'#fff', marginBottom:14 }}>
            {type === 'monthly' ? 'Set Up a Monthly Donation' : 'Make a One-Time Donation'}
          </h2>
          <p style={{ fontSize:14, color:'rgba(255,255,255,.75)', lineHeight:1.75, maxWidth:460, margin:'0 auto 20px' }}>
            {type === 'monthly'
              ? 'Monthly giving provides steady support for the masjid and its programs. Cancel anytime.'
              : 'Secure donation processed via Zeffy — 0% platform fees, so more goes directly to ICH.'}
          </p>
          <p style={{ fontSize:12, color:'rgba(255,255,255,.45)', marginBottom:24 }}>
            By check: payable to "Islamic Center of Hattiesburg" — 211 N 25th Ave, Hattiesburg, MS 39401
          </p>
          <a href={type === 'monthly' ? ZEFFY_MONTHLY : ZEFFY_ONE_TIME}
            target="_blank" rel="noopener noreferrer"
            style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'13px 32px', background:ICH.gold, color:'#fff', borderRadius:4, fontWeight:700, fontSize:15, textDecoration:'none', fontFamily:'Inter,sans-serif', transition:'background .15s' }}
            onMouseEnter={e => e.currentTarget.style.background = ICH.goldDark}
            onMouseLeave={e => e.currentTarget.style.background = ICH.gold}
          >
            ♥ {type === 'monthly' ? 'Set Up Monthly Giving' : 'Donate Now via Zeffy'}
          </a>
          <p style={{ fontSize:11, color:'rgba(255,255,255,.3)', marginTop:14, fontFamily:'Inter,sans-serif' }}>
            Powered by Zeffy — a free, no-fee fundraising platform
          </p>
        </div>
      </div>
    </div>
  );
}

function AdminPage() {
  return (
    <div className="page-enter" style={{ maxWidth:480, margin:'80px auto', padding:'0 24px' }}>
      <div style={{ background:'#fff', border:`1px solid ${ICH.border}`, borderRadius:8, padding:'40px 36px' }}>
        <div style={{ textAlign:'center', marginBottom:28 }}>
          <img src="uploads/logo.png" alt="ICH" style={{ height:48, marginBottom:16 }}/>
          <h1 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:26, fontWeight:600 }}>Admin Login</h1>
          <p style={{ fontSize:13, color:ICH.textMuted, marginTop:4 }}>Restricted access — ICH staff only</p>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <div>
            <label style={{ display:'block', fontSize:11, fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase', color:ICH.textMuted, fontFamily:'Inter,sans-serif', marginBottom:5 }}>Email</label>
            <input type="email" placeholder="admin@ichattiesburg.org" style={{ width:'100%', padding:'10px 14px', border:`1px solid ${ICH.border}`, borderRadius:4, fontSize:14, fontFamily:'Inter,sans-serif' }}/>
          </div>
          <div>
            <label style={{ display:'block', fontSize:11, fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase', color:ICH.textMuted, fontFamily:'Inter,sans-serif', marginBottom:5 }}>Password</label>
            <input type="password" placeholder="••••••••" style={{ width:'100%', padding:'10px 14px', border:`1px solid ${ICH.border}`, borderRadius:4, fontSize:14, fontFamily:'Inter,sans-serif' }}/>
          </div>
          <Btn variant="primary" size="lg" style={{ width:'100%', justifyContent:'center', marginTop:4 }}>Sign In</Btn>
        </div>
      </div>
    </div>
  );
}

// ── App Router ────────────────────────────────────────────────────────────────

function App() {
  const [page, setPage] = React.useState('home');

  const goTo = (id) => { setPage(id); window.scrollTo({ top:0, behavior:'smooth' }); };

  const pages = {
    'home':         <HomePage         setPage={goTo}/>,
    'prayer-times': <PrayerTimesPage  setPage={goTo}/>,
    'events':       <EventsPage       setPage={goTo}/>,
    'about':        <AboutPage        setPage={goTo}/>,
    'resources':    <ResourcesPage    setPage={goTo}/>,
    'contact':      <ContactPage/>,
    'donate':       <DonatePage       setPage={goTo}/>,
    'admin':        <AdminPage/>,
  };

  return (
    <div style={{ minHeight:'100vh', display:'flex', flexDirection:'column' }}>
      <Navbar page={page} setPage={goTo}/>
      <main style={{ flex:1 }} key={page}>
        {pages[page] || pages['home']}
      </main>
      <Footer setPage={goTo}/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
