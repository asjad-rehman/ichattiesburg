// ich-about-resources-contact.jsx — About, Resources, Contact pages

// ── About Page ────────────────────────────────────────────────────────────────

const BOARD_MEMBERS = [
  { name:'Abdul Karim',                  role:'President'           },
  { name:'Muhammad Asjad Rehman Hashmi', role:'Vice President & Imam'},
  { name:'Vacant',                       role:'Secretary'           },
  { name:'Mohammed Kher Bni Salameh',    role:'Treasurer'           },
  { name:'Musa Al Hadwan',               role:'Maintenance'         },
  { name:'Sayed Ul Akbar Murad',         role:'Tech Lead'           },
];

const INITIATIVES = [
  { icon:'📚', title:'Sunday School',          time:'Sundays 9 AM – 1 PM',              note:'Postponed until further notice', desc:'Islamic education for boys and girls up to age 12.' },
  { icon:'🤝', title:'Friday Halaqah (Brothers)', time:'Fridays, Maghrib to Isha',         note:'Dinner served',                  desc:'Strengthening faith through discussion. Current read: Proofs of God and rejection of Atheism.' },
  { icon:'🌸', title:'Sunday Halaqah (Sisters)',  time:'Sundays after Sunday School',      note:'Potluck — bring a dish',         desc:'Sisters-only gathering for Quran and Islamic discussion.' },
  { icon:'☪️', title:'New Reverts Program',       time:'Friday evenings',                  note:'',                               desc:'Spiritual development and deeper understandings of Islam for new Muslims.' },
  { icon:'🍽️', title:'Quarterly Family Potluck', time:'Every quarter',                     note:'',                               desc:'Community-wide gathering for brothers, sisters, and children.' },
  { icon:'🏗️', title:'New Masjid Project',        time:'Ongoing',                          note:'Donations needed',               desc:'Building a new masjid with a large prayer hall, Islamic school, and community center.' },
];

function AboutPage({ setPage }) {
  return (
    <div className="page-enter">

      {/* Page hero */}
      <div style={{ background:`linear-gradient(160deg,${ICH.primaryDark},${ICH.primary})`, padding:'64px 24px 56px', position:'relative', overflow:'hidden' }}>
        <div className="geo-bg" style={{ position:'absolute', inset:0, opacity:.55 }}/>
        <div style={{ maxWidth:800, margin:'0 auto', position:'relative' }}>
          <GoldLabel>Islamic Center of Hattiesburg</GoldLabel>
          <h1 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:'clamp(34px,5vw,56px)', fontWeight:600, color:'#fff', marginBottom:14 }}>About ICH</h1>
          <p style={{ fontSize:'clamp(15px,1.6vw,18px)', color:'rgba(255,255,255,.75)', lineHeight:1.8, maxWidth:560 }}>
            Serving the Muslim community of Hattiesburg, Mississippi with faith, education, and community.
          </p>
        </div>
      </div>

      <div style={{ maxWidth:900, margin:'0 auto', padding:'60px 24px 80px' }}>

        {/* Mission */}
        <section style={{ marginBottom:60 }}>
          <div style={{ border:`1px solid ${ICH.gold}44`, borderRadius:8, padding:'36px 40px', background:`${ICH.gold}07`, position:'relative', overflow:'hidden' }}>
            <div className="geo-bg" style={{ position:'absolute', inset:0, opacity:.6 }}/>
            <div style={{ position:'relative' }}>
              <div className="amiri" style={{ fontSize:'clamp(20px,2.5vw,28px)', color:ICH.primary, marginBottom:10, direction:'rtl', textAlign:'right', lineHeight:1.8 }}>
                وَاللَّهُ يَدْعُو إِلَىٰ دَارِ السَّلَامِ
              </div>
              <p style={{ fontSize:13, color:ICH.textMuted, fontStyle:'italic', textAlign:'right', marginBottom:24 }}>
                "And Allah invites to the Home of Peace" — Surah Yunus, Verse 25
              </p>
              <h2 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:28, fontWeight:600, marginBottom:12 }}>Our Mission</h2>
              <p style={{ fontSize:15, color:ICH.textMuted, lineHeight:1.8 }}>
                The Islamic Center of Hattiesburg stands as a beacon of faith and community. Our mission is to foster a vibrant and inclusive environment where Muslims of all backgrounds can come together to worship, learn, and serve. We strive to promote the principles of Islam, advance education, and provide essential services that enhance the quality of life for our community members.
              </p>
            </div>
          </div>
        </section>

        {/* Board */}
        <section style={{ marginBottom:60 }}>
          <SectionHead label="Leadership" title="Board @ Islamic Center"/>
          <div style={{ border:`1px solid ${ICH.border}`, borderRadius:8, overflow:'hidden' }}>
            {BOARD_MEMBERS.map((member, i) => (
              <div key={member.name} style={{
                display:'flex', justifyContent:'space-between', alignItems:'center',
                padding:'16px 24px',
                background: i % 2 === 0 ? '#fff' : ICH.bgCard,
                borderBottom: i < BOARD_MEMBERS.length - 1 ? `1px solid ${ICH.border}` : 'none',
              }}>
                <div style={{ display:'flex', alignItems:'center', gap:14 }}>
                  <div style={{ width:38, height:38, borderRadius:'50%', background:`${ICH.primary}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, fontWeight:700, color:ICH.primary, fontFamily:'Cormorant Garamond,serif', flexShrink:0 }}>
                    {member.name === 'Vacant' ? '—' : member.name.split(' ').map(w => w[0]).slice(0,2).join('')}
                  </div>
                  <span style={{ fontFamily:'Cormorant Garamond,serif', fontSize:18, fontWeight:600, color: member.name === 'Vacant' ? ICH.textMuted : ICH.text, fontStyle: member.name === 'Vacant' ? 'italic' : 'normal' }}>{member.name}</span>
                </div>
                <span style={{ fontSize:12, fontWeight:600, letterSpacing:'.06em', textTransform:'uppercase', color:ICH.primary, fontFamily:'Inter,sans-serif', background:`${ICH.primary}10`, padding:'4px 12px', borderRadius:20 }}>{member.role}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Initiatives */}
        <section style={{ marginBottom:60 }}>
          <SectionHead label="Programs" title="Our Initiatives"/>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))', gap:16 }}>
            {INITIATIVES.map(item => (
              <Card key={item.title} hover style={{ position:'relative' }}>
                <div style={{ display:'flex', gap:12, alignItems:'flex-start', marginBottom:10 }}>
                  <span style={{ fontSize:24, flexShrink:0 }}>{item.icon}</span>
                  <div>
                    <h3 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:19, fontWeight:600, marginBottom:2 }}>{item.title}</h3>
                    <div style={{ fontSize:11, color:ICH.primary, fontWeight:600, fontFamily:'Inter,sans-serif' }}>{item.time}</div>
                  </div>
                </div>
                <p style={{ fontSize:13, color:ICH.textMuted, lineHeight:1.65, marginBottom: item.note ? 10 : 0 }}>{item.desc}</p>
                {item.note && (
                  <div style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:11, fontWeight:600, color:ICH.gold, fontFamily:'Inter,sans-serif' }}>
                    <span>★</span> {item.note}
                  </div>
                )}
              </Card>
            ))}
          </div>
        </section>

        {/* Oak Grove Project */}
        <section id="oak-grove" style={{ scrollMarginTop:80, marginBottom:60 }}>
          <div style={{ border:`2px solid ${ICH.gold}55`, borderRadius:8, padding:'36px 40px', background:`linear-gradient(135deg,${ICH.bgCard},#fff)` }}>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:6 }}>
              <span style={{ fontSize:24 }}>🏗️</span>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:'.12em', textTransform:'uppercase', color:ICH.gold, fontFamily:'Inter,sans-serif' }}>Active Project</div>
            </div>
            <h2 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:32, fontWeight:600, marginBottom:16 }}>New Masjid Project</h2>
            <p style={{ fontSize:15, color:ICH.textMuted, lineHeight:1.8, marginBottom:24 }}>
              As a growing community our current facility continues to be a challenge. We are planning to address this concern by building a new masjid that will offer a large prayer hall, an Islamic school, and a community center, insha'Allah. Please spread the word and donate wholeheartedly.
            </p>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:24 }}>
              {[['Status','In Progress'],['Location','Hattiesburg, MS'],['Goal','New Masjid Facility']].map(([label,value]) => (
                <div key={label} style={{ textAlign:'center', background:'#fff', border:`1px solid ${ICH.border}`, borderRadius:5, padding:'14px 10px' }}>
                  <div style={{ fontSize:10, fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', color:ICH.textMuted, fontFamily:'Inter,sans-serif', marginBottom:5 }}>{label}</div>
                  <div style={{ fontSize:15, fontWeight:600, color:ICH.text }}>{value}</div>
                </div>
              ))}
            </div>
            <Btn variant="gold" onClick={() => { setPage('donate'); window.scrollTo(0,0); }}>♥ Support the New Masjid</Btn>
          </div>
        </section>

        {/* Location */}
        <section>
          <SectionHead label="Visit Us" title="Location & Hours"/>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))', gap:16, marginBottom:16 }}>
            <Card>
              <div style={{ fontSize:11, fontWeight:700, letterSpacing:'.1em', textTransform:'uppercase', color:ICH.primary, fontFamily:'Inter,sans-serif', marginBottom:10 }}>📍 Address</div>
              <p style={{ fontSize:14, color:ICH.textMuted, lineHeight:1.7 }}>211 N 25th Avenue<br/>Hattiesburg, MS 39401</p>
            </Card>
            <Card>
              <div style={{ fontSize:11, fontWeight:700, letterSpacing:'.1em', textTransform:'uppercase', color:ICH.primary, fontFamily:'Inter,sans-serif', marginBottom:10 }}>🕌 Open For Prayers</div>
              <p style={{ fontSize:13, color:ICH.textMuted, lineHeight:1.7 }}>The masjid is open for all five daily prayers. Check the prayer times page for the current schedule. Special events may have different hours.</p>
            </Card>
          </div>
          <div style={{ borderRadius:8, overflow:'hidden', border:`1px solid ${ICH.border}`, height:280 }}>
            <iframe
              src="https://www.openstreetmap.org/export/embed.html?bbox=-89.32,31.28,-89.28,31.32&layer=mapnik&marker=31.302,-89.301"
              width="100%" height="100%" style={{ border:0 }} loading="lazy" title="ICH Location"
            />
          </div>
        </section>
      </div>
    </div>
  );
}

// ── Resources Page ────────────────────────────────────────────────────────────

const RESOURCES = [
  { category:'Quran & Hadith', icon:'📖', links:[
    { label:'Quran.com — Quran with Translation',     url:'https://quran.com' },
    { label:'Sunnah.com — Hadith Collections',        url:'https://sunnah.com' },
    { label:'IslamQA.info — Islamic Q&A',             url:'https://islamqa.info' },
  ]},
  { category:'Islamic Media', icon:'🎙️', links:[
    { label:'SeekersGuidance — Free Islamic Courses', url:'https://seekersguidance.org' },
    { label:'Yaqeen Institute — Islamic Research',    url:'https://yaqeeninstitute.org' },
    { label:'MuslimMatters.org — Articles & Essays',  url:'https://muslimmatters.org' },
  ]},
  { category:'Prayer & Zakat Tools', icon:'🤲', links:[
    { label:'ISNA — Islamic Society of North America', url:'https://isna.net' },
    { label:'National Zakat Foundation',               url:'https://nzf.org.uk' },
    { label:'Islamic Relief — Zakat Calculator',       url:'https://www.islamicrelief.org/zakat/calculator/' },
  ]},
  { category:'Community & Organizations', icon:'🌐', links:[
    { label:'Islamic Society of North America (ISNA)', url:'https://isna.net' },
    { label:'Muslim American Society (MAS)',           url:'https://mas-icna.org' },
    { label:'CAIR — Council on American-Islamic Relations', url:'https://www.cair.com' },
  ]},
];

function ResourcesPage({ setPage }) {
  return (
    <div className="page-enter" style={{ maxWidth:900, margin:'0 auto', padding:'52px 24px 80px' }}>
      <div style={{ marginBottom:44 }}>
        <GoldLabel>Learning & Growth</GoldLabel>
        <h1 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:'clamp(32px,5vw,52px)', fontWeight:600, marginBottom:10 }}>Islamic Resources</h1>
        <p style={{ fontSize:16, color:ICH.textMuted }}>Curated resources for learning, practice, and community connection.</p>
      </div>

      <div style={{ background:ICH.bgCard, border:`1px solid ${ICH.border}`, borderRadius:8, padding:'28px 32px', textAlign:'center', marginBottom:44 }}>
        <div className="amiri" style={{ fontSize:'clamp(20px,2.8vw,28px)', color:ICH.primary, marginBottom:10, direction:'rtl', lineHeight:1.8 }}>
          اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ
        </div>
        <p style={{ fontSize:13, color:ICH.textMuted, fontStyle:'italic' }}>"Read in the name of your Lord who created." — Quran 96:1</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:16, marginBottom:36 }}>
        {RESOURCES.map(group => (
          <Card key={group.category} hover>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:16 }}>
              <span style={{ fontSize:20 }}>{group.icon}</span>
              <h3 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:20, fontWeight:600, color:ICH.primary }}>{group.category}</h3>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {group.links.map(link => (
                <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer"
                  style={{ display:'flex', gap:8, alignItems:'flex-start', fontSize:13, color:ICH.textMuted, textDecoration:'none', transition:'color .15s', lineHeight:1.55 }}
                  onMouseEnter={e => e.currentTarget.style.color = ICH.primary}
                  onMouseLeave={e => e.currentTarget.style.color = ICH.textMuted}
                >
                  <span style={{ flexShrink:0, marginTop:1, color:ICH.gold }}>↗</span>
                  {link.label}
                </a>
              ))}
            </div>
          </Card>
        ))}
      </div>

      <div style={{ padding:24, background:ICH.bgCard, border:`1px solid ${ICH.border}`, borderRadius:6 }}>
        <h3 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:20, marginBottom:6 }}>Suggest a Resource</h3>
        <p style={{ fontSize:13, color:ICH.textMuted, marginBottom:14, lineHeight:1.65 }}>Have a useful Islamic resource to share with the community? We'd love to hear from you.</p>
        <Btn variant="outline" onClick={() => { setPage('contact'); window.scrollTo(0,0); }} size="sm">Send a Suggestion →</Btn>
      </div>
    </div>
  );
}

// ── Contact Page ──────────────────────────────────────────────────────────────

function ContactPage() {
  const [form,   setForm]   = React.useState({ name:'', email:'', subject:'', message:'' });
  const [status, setStatus] = React.useState('idle');

  const set = (k, v) => setForm(f => ({ ...f, [k]:v }));

  const submit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setStatus('sending');
    setTimeout(() => setStatus('sent'), 1400);
  };

  const inputStyle = {
    width:'100%', padding:'10px 14px', border:`1px solid ${ICH.border}`,
    borderRadius:4, fontSize:14, fontFamily:'Inter,sans-serif',
    background:'#fff', color:ICH.text, outline:'none', transition:'border-color .15s',
  };
  const labelStyle = {
    display:'block', fontSize:11, fontWeight:600, color:ICH.textMuted,
    marginBottom:5, letterSpacing:'.04em', textTransform:'uppercase', fontFamily:'Inter,sans-serif',
  };

  return (
    <div className="page-enter" style={{ maxWidth:1000, margin:'0 auto', padding:'52px 24px 80px' }}>
      <div style={{ marginBottom:44 }}>
        <GoldLabel>Get in Touch</GoldLabel>
        <h1 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:'clamp(32px,5vw,52px)', fontWeight:600, marginBottom:10 }}>Contact Us</h1>
        <p style={{ fontSize:16, color:ICH.textMuted }}>We'd love to hear from you. Reach out with any questions or comments.</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:40 }}>
        {/* Info */}
        <div>
          <div style={{ display:'flex', flexDirection:'column', gap:12, marginBottom:24 }}>
            {[
              { icon:'📍', label:'Address',      content:'211 N 25th Avenue\nHattiesburg, MS 39401' },
              { icon:'✉️', label:'Email',         content:'ICHattiesburg@protonmail.com' },
              { icon:'🕌', label:'Prayer Times', content:'Open for all five daily prayers.\nSee prayer times page for schedule.' },
            ].map(item => (
              <Card key={item.label} style={{ display:'flex', gap:14, alignItems:'flex-start', padding:'16px 18px' }}>
                <div style={{ width:40, height:40, borderRadius:6, background:`${ICH.primary}12`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, flexShrink:0 }}>{item.icon}</div>
                <div>
                  <div style={{ fontSize:11, fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase', color:ICH.primary, fontFamily:'Inter,sans-serif', marginBottom:3 }}>{item.label}</div>
                  <p style={{ fontSize:13, color:ICH.textMuted, lineHeight:1.65, whiteSpace:'pre-line' }}>{item.content}</p>
                </div>
              </Card>
            ))}
          </div>

          <Card>
            <div style={{ fontSize:11, fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase', color:ICH.primary, fontFamily:'Inter,sans-serif', marginBottom:12 }}>Social Media</div>
            <div style={{ display:'flex', gap:10 }}>
              <a href="https://www.facebook.com/ichattiesburg" target="_blank" rel="noopener noreferrer"
                style={{ padding:'8px 16px', background:'#1877F2', color:'#fff', borderRadius:4, fontSize:13, fontWeight:500, textDecoration:'none', fontFamily:'Inter,sans-serif' }}>Facebook</a>
              <a href="https://www.instagram.com/ichattiesburg" target="_blank" rel="noopener noreferrer"
                style={{ padding:'8px 16px', background:'linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888)', color:'#fff', borderRadius:4, fontSize:13, fontWeight:500, textDecoration:'none', fontFamily:'Inter,sans-serif' }}>Instagram</a>
            </div>
          </Card>
        </div>

        {/* Form */}
        <div>
          {status === 'sent' ? (
            <div style={{ textAlign:'center', padding:'60px 24px', background:ICH.bgCard, borderRadius:8, border:`1px solid ${ICH.primary}33` }}>
              <div style={{ fontSize:48, marginBottom:16 }}>✅</div>
              <h3 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:26, marginBottom:10 }}>Message Sent</h3>
              <p style={{ fontSize:14, color:ICH.textMuted, lineHeight:1.7 }}>JazakAllah Khayran! We'll be in touch soon, insha'Allah.</p>
              <div style={{ marginTop:20 }}>
                <Btn variant="outline" onClick={() => { setForm({ name:'', email:'', subject:'', message:'' }); setStatus('idle'); }} size="sm">Send Another</Btn>
              </div>
            </div>
          ) : (
            <form onSubmit={submit}>
              <h2 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:26, fontWeight:600, marginBottom:24 }}>Send a Message</h2>
              <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
                  <div>
                    <label style={labelStyle}>Name *</label>
                    <input value={form.name} onChange={e => set('name',e.target.value)} placeholder="Your name" style={inputStyle} required
                      onFocus={e => e.target.style.borderColor=ICH.primary} onBlur={e => e.target.style.borderColor=ICH.border}/>
                  </div>
                  <div>
                    <label style={labelStyle}>Email *</label>
                    <input type="email" value={form.email} onChange={e => set('email',e.target.value)} placeholder="your@email.com" style={inputStyle} required
                      onFocus={e => e.target.style.borderColor=ICH.primary} onBlur={e => e.target.style.borderColor=ICH.border}/>
                  </div>
                </div>
                <div>
                  <label style={labelStyle}>Subject</label>
                  <input value={form.subject} onChange={e => set('subject',e.target.value)} placeholder="What is this about?" style={inputStyle}
                    onFocus={e => e.target.style.borderColor=ICH.primary} onBlur={e => e.target.style.borderColor=ICH.border}/>
                </div>
                <div>
                  <label style={labelStyle}>Message *</label>
                  <textarea value={form.message} onChange={e => set('message',e.target.value)} placeholder="Your message..." rows={6} required
                    style={{ ...inputStyle, resize:'vertical', lineHeight:1.6 }}
                    onFocus={e => e.target.style.borderColor=ICH.primary} onBlur={e => e.target.style.borderColor=ICH.border}/>
                </div>
                <Btn variant="primary" size="lg" style={{ width:'100%', justifyContent:'center' }}>
                  {status === 'sending' ? '⏳ Sending…' : '✉️ Send Message'}
                </Btn>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { AboutPage, ResourcesPage, ContactPage });
