// ich-shared.jsx — Navbar, Footer, shared UI components

const ICH = {
  primary:      '#6d4c41',
  primaryDark:  '#3f2318',
  primaryMid:   '#5a3a30',
  primaryLight: '#8d6357',
  gold:         '#c8a96e',
  goldLight:    '#d9be8a',
  goldDark:     '#9a7a3e',
  bg:           '#faf9f6',
  bgCard:       '#f4f0eb',
  bgCard2:      '#ede7df',
  text:         '#1c1a17',
  textMuted:    '#6b6458',
  border:       '#ddd5ca',
  footerBg:     '#1e0e08',
};

// ── Shared primitives ─────────────────────────────────────────────────────────

function Btn({ children, variant = 'primary', onClick, href, style = {}, size = 'md' }) {
  const pad = size === 'sm' ? '7px 16px' : size === 'lg' ? '13px 30px' : '10px 22px';
  const fs  = size === 'sm' ? 13 : size === 'lg' ? 15 : 14;
  const base = {
    display: 'inline-flex', alignItems: 'center', gap: 7,
    padding: pad, borderRadius: 3, fontSize: fs, fontWeight: 500,
    fontFamily: 'Inter, sans-serif', cursor: 'pointer', border: 'none',
    textDecoration: 'none', transition: 'all .18s ease', letterSpacing: '.015em',
    whiteSpace: 'nowrap',
  };
  const variants = {
    primary:      { background: ICH.primary,     color: '#fff' },
    gold:         { background: ICH.gold,         color: '#fff' },
    'outline':    { background: 'transparent',   color: ICH.primary,  border: `1.5px solid ${ICH.primary}` },
    'ghost-dark': { background: 'rgba(255,255,255,.13)', color: '#fff', border: '1.5px solid rgba(255,255,255,.28)' },
    muted:        { background: ICH.bgCard2,      color: ICH.text,     border: `1px solid ${ICH.border}` },
  };
  const Tag = href ? 'a' : 'button';
  return (
    <Tag href={href} onClick={onClick}
      style={{ ...base, ...variants[variant], ...style }}
      onMouseEnter={e => { e.currentTarget.style.opacity = '.84'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
      onMouseLeave={e => { e.currentTarget.style.opacity = '1';   e.currentTarget.style.transform = 'translateY(0)'; }}
    >{children}</Tag>
  );
}

function GoldLabel({ children }) {
  return (
    <div style={{ display:'inline-flex', alignItems:'center', gap:10, marginBottom:12 }}>
      <span style={{ width:22, height:1.5, background:ICH.gold, display:'block' }}/>
      <span style={{ fontSize:11, fontWeight:600, letterSpacing:'.14em', textTransform:'uppercase', color:ICH.gold, fontFamily:'Inter, sans-serif' }}>
        {children}
      </span>
      <span style={{ width:22, height:1.5, background:ICH.gold, display:'block' }}/>
    </div>
  );
}

function SectionHead({ label, title, sub, center, light }) {
  return (
    <div style={{ textAlign: center ? 'center' : 'left', marginBottom: 40 }}>
      {label && <GoldLabel>{label}</GoldLabel>}
      <h2 style={{
        fontFamily: 'Cormorant Garamond, serif', fontWeight: 600,
        fontSize: 'clamp(26px,3.8vw,40px)', color: light ? '#fff' : ICH.text,
        marginBottom: sub ? 12 : 0,
      }}>{title}</h2>
      {sub && <p style={{ fontSize:16, color: light ? 'rgba(255,255,255,.7)' : ICH.textMuted, maxWidth: center ? 520 : 'none', margin: center ? '0 auto' : 0, lineHeight:1.7 }}>{sub}</p>}
    </div>
  );
}

function Card({ children, style = {}, hover = false }) {
  const [hov, setHov] = React.useState(false);
  return (
    <div
      style={{ background: ICH.bgCard, border: `1px solid ${hov && hover ? ICH.primary+'55' : ICH.border}`, borderRadius:6, padding:24, transition:'border-color .2s, box-shadow .2s', boxShadow: hov && hover ? '0 4px 18px rgba(27,94,32,.09)' : 'none', ...style }}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
    >{children}</div>
  );
}

function Tag({ children, color }) {
  const colors = {
    green:  ['#dcf5e4','#1b5e20'], yellow: ['#fef9e0','#7a6000'],
    blue:   ['#e0eeff','#1a3a7a'], purple: ['#f0e0ff','#4a1a7a'],
    orange: ['#fff0e0','#7a3a00'], teal:   ['#e0f5f5','#0a4a4a'],
    gray:   ['#f0f0f0','#404040'],
  };
  const [bg, fg] = colors[color] || colors.gray;
  return <span style={{ display:'inline-block', padding:'3px 10px', borderRadius:20, fontSize:11, fontWeight:600, background:bg, color:fg, letterSpacing:'.04em', textTransform:'capitalize', fontFamily:'Inter, sans-serif' }}>{children}</span>;
}

// ── Navbar ────────────────────────────────────────────────────────────────────

function Navbar({ page, setPage }) {
  const [open,    setOpen]    = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  React.useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);

  const links = [
    { id:'home',         label:'Home' },
    { id:'prayer-times', label:'Prayer Times' },
    { id:'events',       label:'Events' },
    { id:'about',        label:'About' },
    { id:'resources',    label:'Resources' },
    { id:'contact',      label:'Contact' },
  ];

  const nav = (link) => { setPage(link); setOpen(false); window.scrollTo(0,0); };

  return (
    <header style={{
      position:'sticky', top:0, zIndex:200,
      background: scrolled ? 'rgba(250,249,246,.97)' : 'rgba(250,249,246,.99)',
      backdropFilter:'blur(14px)',
      borderBottom: `1px solid ${scrolled ? ICH.border : 'transparent'}`,
      boxShadow: scrolled ? '0 1px 10px rgba(0,0,0,.07)' : 'none',
      transition:'all .3s',
    }}>
      <div style={{ maxWidth:1200, margin:'0 auto', padding:'0 24px', display:'flex', alignItems:'center', justifyContent:'space-between', height:66 }}>

        {/* Logo */}
        <div style={{ cursor:'pointer', flexShrink:0 }} onClick={() => nav('home')} aria-label="Home">
          <img src="uploads/logo.png" alt="Islamic Center of Hattiesburg" style={{ height:46, width:'auto', display:'block' }}/>
        </div>

        {/* Desktop nav */}
        <nav className="desktop-nav" aria-label="Main" style={{ display:'flex', alignItems:'center', gap:2 }}>
          {links.map(l => (
            <button key={l.id} onClick={() => nav(l.id)} style={{
              padding:'7px 12px', background: page === l.id ? `${ICH.primary}14` : 'transparent',
              color: page === l.id ? ICH.primary : ICH.textMuted,
              border:'none', cursor:'pointer', fontFamily:'Inter,sans-serif', fontSize:13.5, fontWeight: page===l.id ? 500 : 400,
              borderRadius:4, transition:'all .15s',
            }}
            onMouseEnter={e => { if(page!==l.id){ e.currentTarget.style.color=ICH.text; e.currentTarget.style.background='rgba(0,0,0,.04)'; }}}
            onMouseLeave={e => { if(page!==l.id){ e.currentTarget.style.color=ICH.textMuted; e.currentTarget.style.background='transparent'; }}}
            >{l.label}</button>
          ))}
        </nav>

        {/* Right actions */}
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <button onClick={() => nav('donate')} style={{
            padding:'8px 20px', background:ICH.gold, color:'#fff',
            border:'none', cursor:'pointer', borderRadius:3,
            fontFamily:'Inter,sans-serif', fontSize:13, fontWeight:600, letterSpacing:'.02em',
            transition:'background .15s',
          }}
          onMouseEnter={e => e.currentTarget.style.background = ICH.goldDark}
          onMouseLeave={e => e.currentTarget.style.background = ICH.gold}
          >♥ Donate</button>

          <button className="mobile-btn" onClick={() => setOpen(!open)} style={{
            display:'none', padding:8, background:'transparent', border:'none',
            cursor:'pointer', color:ICH.text, fontSize:20, lineHeight:1,
          }}>{open ? '✕' : '☰'}</button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="mobile-menu" style={{ borderTop:`1px solid ${ICH.border}`, background:ICH.bg, padding:'10px 16px 14px' }}>
          {links.map(l => (
            <button key={l.id} onClick={() => nav(l.id)} style={{
              display:'block', width:'100%', textAlign:'left',
              padding:'10px 12px', background: page===l.id ? `${ICH.primary}14` : 'transparent',
              color: page===l.id ? ICH.primary : ICH.text,
              border:'none', cursor:'pointer', fontFamily:'Inter,sans-serif', fontSize:15, fontWeight: page===l.id ? 500 : 400,
              borderRadius:4, marginBottom:2,
            }}>{l.label}</button>
          ))}
          <button onClick={() => nav('donate')} style={{
            marginTop:8, width:'100%', padding:'11px 12px',
            background:ICH.gold, color:'#fff', border:'none', cursor:'pointer',
            borderRadius:4, fontFamily:'Inter,sans-serif', fontSize:14, fontWeight:600,
          }}>♥ Donate Now</button>
        </div>
      )}
    </header>
  );
}

// ── Footer ────────────────────────────────────────────────────────────────────

function Footer({ setPage }) {
  const nav = (id) => { setPage(id); window.scrollTo(0,0); };
  const col = {
    label: { fontSize:10, fontWeight:700, letterSpacing:'.14em', textTransform:'uppercase', color:ICH.gold, marginBottom:14, fontFamily:'Inter,sans-serif' },
    link:  { background:'none', border:'none', cursor:'pointer', textAlign:'left', padding:0, color:'rgba(255,255,255,.6)', fontSize:13.5, fontFamily:'Inter,sans-serif', transition:'color .15s', display:'block', marginBottom:8 },
  };
  const hov  = e => { e.currentTarget.style.color = '#fff'; };
  const unhov = e => { e.currentTarget.style.color = 'rgba(255,255,255,.6)'; };

  return (
    <footer style={{ background:ICH.footerBg, color:'#fff' }}>
      <div style={{ height:2, background:`linear-gradient(90deg,transparent,${ICH.gold},transparent)` }}/>
      <div style={{ maxWidth:1200, margin:'0 auto', padding:'52px 24px 36px' }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(190px,1fr))', gap:40, marginBottom:44 }}>

          {/* Brand */}
          <div>
            <img src="uploads/logo.png" alt="ICH" style={{ height:52, filter:'brightness(0) invert(1)', marginBottom:16 }}/>
            <p style={{ fontSize:13, color:'rgba(255,255,255,.55)', lineHeight:1.75, marginBottom:18 }}>
              Serving the Muslim community of Hattiesburg, Mississippi with prayer, education, and community programs.
            </p>
            <div className="amiri" style={{ fontSize:19, color:ICH.gold, lineHeight:2 }}>
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </div>
          </div>

          {/* Links */}
          <div>
            <div style={col.label}>Quick Links</div>
            {[['prayer-times','Prayer Times'],['events','Events Calendar'],['donate','Donate'],['about','About ICH'],['resources','Islamic Resources'],['contact','Contact']].map(([id,label]) => (
              <button key={id} style={col.link} onClick={() => nav(id)} onMouseEnter={hov} onMouseLeave={unhov}>{label}</button>
            ))}
          </div>

          {/* Contact */}
          <div>
            <div style={col.label}>Contact</div>
            <div style={{ display:'flex', flexDirection:'column', gap:11 }}>
              {[['📍','211 N 25th Avenue\nHattiesburg, MS 39401'],['✉️','ICHattiesburg@protonmail.com']].map(([icon, text]) => (
                <div key={icon} style={{ display:'flex', gap:10, alignItems:'flex-start' }}>
                  <span style={{ fontSize:13, flexShrink:0, marginTop:2 }}>{icon}</span>
                  <span style={{ fontSize:13, color:'rgba(255,255,255,.6)', lineHeight:1.65, whiteSpace:'pre-line' }}>{text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Social */}
          <div>
            <div style={col.label}>Follow Us</div>
            <div style={{ display:'flex', gap:8, marginBottom:24 }}>
              {['Facebook','Instagram'].map(s => (
                <a key={s} href={`https://www.${s.toLowerCase()}.com/ichattiesburg`} target="_blank" rel="noopener noreferrer"
                  style={{ padding:'7px 14px', background:'rgba(255,255,255,.07)', color:'rgba(255,255,255,.75)', borderRadius:3, fontSize:12, fontWeight:500, textDecoration:'none', border:'1px solid rgba(255,255,255,.1)', fontFamily:'Inter,sans-serif', transition:'all .15s' }}
                  onMouseEnter={e => { e.currentTarget.style.background='rgba(255,255,255,.14)'; e.currentTarget.style.color='#fff'; }}
                  onMouseLeave={e => { e.currentTarget.style.background='rgba(255,255,255,.07)'; e.currentTarget.style.color='rgba(255,255,255,.75)'; }}
                >{s}</a>
              ))}
            </div>
            <button onClick={() => nav('admin')} style={{ background:'none', border:'none', cursor:'pointer', fontSize:11, color:'rgba(255,255,255,.25)', fontFamily:'Inter,sans-serif' }}
              onMouseEnter={e => e.currentTarget.style.color='rgba(255,255,255,.55)'}
              onMouseLeave={e => e.currentTarget.style.color='rgba(255,255,255,.25)'}
            >Admin Login</button>
          </div>
        </div>

        <div style={{ borderTop:'1px solid rgba(255,255,255,.09)', paddingTop:22, display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
          <p style={{ fontSize:12, color:'rgba(255,255,255,.35)', fontFamily:'Inter,sans-serif' }}>© {new Date().getFullYear()} Islamic Center of Hattiesburg. All rights reserved.</p>
          <div style={{ display:'flex', gap:18 }}>
            {['Privacy Policy','Sitemap'].map(t => (
              <a key={t} href="#" style={{ fontSize:12, color:'rgba(255,255,255,.35)', textDecoration:'none', fontFamily:'Inter,sans-serif', transition:'color .15s' }}
                onMouseEnter={e => e.currentTarget.style.color='rgba(255,255,255,.7)'}
                onMouseLeave={e => e.currentTarget.style.color='rgba(255,255,255,.35)'}
              >{t}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { ICH, Btn, GoldLabel, SectionHead, Card, Tag, Navbar, Footer });
