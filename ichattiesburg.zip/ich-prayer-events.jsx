// ich-prayer-events.jsx — Prayer Times page + Events page

// ── Prayer Times Page ─────────────────────────────────────────────────────────

function PrayerTimesPage({ setPage }) {
  const { countdown, nextName, nextIdx, curIdx } = usePrayerCountdown();

  const jumuah = [
    { label:'Jumuah 1', time:'12:15 PM' },
    { label:'Jumuah 2', time:'1:15 PM'  },
  ];

  return (
    <div className="page-enter" style={{ maxWidth:1100, margin:'0 auto', padding:'52px 24px 80px' }}>

      {/* Page header */}
      <div style={{ marginBottom:48 }}>
        <GoldLabel>Hattiesburg, Mississippi</GoldLabel>
        <h1 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:'clamp(32px,5vw,52px)', fontWeight:600, marginBottom:10 }}>Prayer Times</h1>
        <p style={{ fontSize:16, color:ICH.textMuted, lineHeight:1.7 }}>Daily prayer schedule for the Islamic Center of Hattiesburg. Times are updated regularly.</p>
      </div>

      {/* ── Live Countdown ── */}
      <div style={{
        background:`linear-gradient(135deg,${ICH.primaryDark},${ICH.primary})`,
        borderRadius:8, padding:'36px 40px', marginBottom:36,
        display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:24,
        position:'relative', overflow:'hidden',
      }}>
        <div className="geo-bg" style={{ position:'absolute', inset:0, opacity:.5 }}/>
        <div style={{ position:'relative' }}>
          <div style={{ fontSize:11, fontWeight:700, letterSpacing:'.14em', textTransform:'uppercase', color:ICH.gold, fontFamily:'Inter,sans-serif', marginBottom:8 }}>Next Prayer</div>
          <div style={{ fontFamily:'Cormorant Garamond,serif', fontSize:'clamp(24px,3vw,36px)', fontWeight:600, color:'#fff' }}>{nextName}</div>
        </div>
        <div style={{ position:'relative', textAlign:'center' }}>
          <div style={{ fontSize:11, fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', color:'rgba(255,255,255,.55)', fontFamily:'Inter,sans-serif', marginBottom:6 }}>Time Remaining</div>
          <div style={{ fontFamily:'Cormorant Garamond,serif', fontSize:'clamp(40px,6vw,68px)', fontWeight:600, color:ICH.gold, letterSpacing:'.05em', lineHeight:1 }}>{countdown}</div>
        </div>
        <div style={{ position:'relative', textAlign:'right' }}>
          <div className="amiri" style={{ fontSize:22, color:ICH.gold, marginBottom:6 }}>
            حَافِظُوا عَلَى الصَّلَوَاتِ
          </div>
          <div style={{ fontSize:12, color:'rgba(255,255,255,.5)', fontFamily:'Inter,sans-serif', fontStyle:'italic' }}>
            "Guard strictly the prayers" — Quran 2:238
          </div>
        </div>
      </div>

      {/* ── Prayer cards grid ── */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))', gap:12, marginBottom:40 }}>
        {PRAYER_TIMES_DATA.map((p, i) => {
          const isCur  = i === curIdx;
          const isNext = i === nextIdx;
          return (
            <div key={p.key} style={{
              textAlign:'center', padding:'28px 16px', borderRadius:6,
              background: isCur ? ICH.primary : isNext ? `${ICH.primary}0e` : '#fff',
              border:`1px solid ${isCur ? ICH.primary : isNext ? ICH.primary+'44' : ICH.border}`,
              boxShadow: isCur ? '0 6px 24px rgba(27,94,32,.22)' : 'var(--shadow-sm)',
              transform: isCur ? 'translateY(-3px) scale(1.03)' : 'none',
              transition:'all .25s', position:'relative',
            }}>
              {isCur && <div style={{ position:'absolute', top:-10, left:'50%', transform:'translateX(-50%)', background:ICH.gold, color:'#fff', fontSize:9, fontWeight:700, padding:'2px 10px', borderRadius:10, fontFamily:'Inter,sans-serif', letterSpacing:'.06em', whiteSpace:'nowrap' }}>CURRENT</div>}
              {isNext && !isCur && <div style={{ position:'absolute', top:-10, left:'50%', transform:'translateX(-50%)', background:ICH.bgCard2, color:ICH.primary, fontSize:9, fontWeight:700, padding:'2px 8px', borderRadius:10, border:`1px solid ${ICH.primary}33`, fontFamily:'Inter,sans-serif', whiteSpace:'nowrap' }}>UP NEXT</div>}
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:'.1em', textTransform:'uppercase', color: isCur ? 'rgba(255,255,255,.65)' : ICH.textMuted, marginBottom:10, fontFamily:'Inter,sans-serif' }}>{p.name}</div>
              <div style={{ fontFamily:'Cormorant Garamond,serif', fontSize:26, fontWeight:600, color: isCur ? '#fff' : ICH.text, marginBottom:4 }}>
                {p.display}
              </div>
              {isCur && (
                <div style={{ fontSize:11, color:'rgba(255,255,255,.6)', fontFamily:'Inter,sans-serif', marginTop:6 }}>In progress</div>
              )}
            </div>
          );
        })}
      </div>

      {/* ── Jumuah section ── */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:24, marginBottom:48 }}>
          <div style={{ border:`1px solid ${ICH.gold}44`, borderRadius:8, padding:28, background:`${ICH.gold}08` }}>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:'.14em', textTransform:'uppercase', color:ICH.gold, fontFamily:'Inter,sans-serif', marginBottom:8 }}>Every Friday</div>
          <h2 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:28, fontWeight:600, marginBottom:20 }}>Jumuah Prayer</h2>
          {jumuah.map(j => (
            <div key={j.label} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'12px 0', borderBottom:`1px solid ${ICH.border}` }}>
              <span style={{ fontSize:14, fontWeight:600, color:ICH.primary }}>{j.label}</span>
              <span style={{ fontFamily:'Cormorant Garamond,serif', fontSize:22, fontWeight:600 }}>{j.time}</span>
            </div>
          ))}
          <div style={{ display:'flex', justifyContent:'space-between', padding:'10px 0', borderBottom:`1px solid ${ICH.border}` }}>
            <span style={{ fontSize:13, color:ICH.textMuted }}>Speaker</span>
            <span style={{ fontSize:14, fontWeight:500 }}>Imam (TBA)</span>
          </div>
          <p style={{ fontSize:13, color:ICH.textMuted, marginTop:16, lineHeight:1.7 }}>All are welcome. Located at 211 N 25th Avenue, Hattiesburg, MS 39401.</p>
        </div>

        <div style={{ border:`1px solid ${ICH.border}`, borderRadius:8, padding:28, background:'#fff' }}>
          <h3 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:22, fontWeight:600, marginBottom:14 }}>Notes on Prayer Times</h3>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {[
              'Prayer times are calculated for Hattiesburg, MS using the ISNA method.',
              'Iqama times may differ from the adhan times shown above.',
              'Please arrive a few minutes early to pray sunnah.',
              'Check the announcements banner for any changes to the schedule.',
            ].map((note, i) => (
              <div key={i} style={{ display:'flex', gap:10, alignItems:'flex-start' }}>
                <span style={{ color:ICH.gold, fontWeight:700, flexShrink:0, marginTop:1 }}>—</span>
                <span style={{ fontSize:13, color:ICH.textMuted, lineHeight:1.65 }}>{note}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop:20 }}>
            <Btn variant="outline" onClick={() => { setPage('contact'); window.scrollTo(0,0); }} size="sm">Contact the Masjid</Btn>
          </div>
        </div>
      </div>

      {/* Quran verse */}
      <div style={{ background:ICH.bgCard, border:`1px solid ${ICH.border}`, borderRadius:8, padding:'32px 36px', textAlign:'center' }}>
        <div className="amiri" style={{ fontSize:'clamp(22px,3vw,30px)', color:ICH.primary, marginBottom:12, lineHeight:1.8, direction:'rtl' }}>
          إِنَّ الصَّلَاةَ كَانَتْ عَلَى الْمُؤْمِنِينَ كِتَابًا مَّوْقُوتًا
        </div>
        <p style={{ fontSize:14, color:ICH.textMuted, fontStyle:'italic' }}>
          "Indeed, prayer has been decreed upon the believers a decree of specified times." — Quran 4:103
        </p>
      </div>
    </div>
  );
}

// ── Events Page ───────────────────────────────────────────────────────────────

const CAT_COLORS = { jumuah:'green', eid:'yellow', halaqa:'blue', fundraiser:'purple', construction:'orange', community:'teal', other:'gray' };

const SAMPLE_EVENTS = (() => {
  const now = new Date();
  const nextDay = (d, dow) => { const r = new Date(d); r.setDate(r.getDate() + (dow - r.getDay() + 7) % 7 || 7); return r; };
  return [
    { id:'1', title:'Jumuah Prayer',           desc:'Weekly Friday prayer with khutbah. All are welcome.',                                                        date: nextDay(now,5), time:'1:00 PM', end:'2:00 PM', location:'Islamic Center of Hattiesburg', category:'jumuah',    featured:true  },
    { id:'2', title:'Weekend Halaqa',           desc:'Quranic tafsir and Islamic discussion for the community.',                                                   date: nextDay(now,0), time:'10:00 AM', end:'11:30 AM', location:'ICH Main Hall',               category:'halaqa',    featured:false },
    { id:'3', title:'Oak Grove Fundraiser Dinner', desc:'Annual fundraiser dinner to support our new masjid building project in Oak Grove. Dinner and program included.', date: new Date(now.getFullYear(), now.getMonth()+1, 15), time:'6:00 PM', end:'9:00 PM', location:'TBA', category:'fundraiser', featured:true  },
    { id:'4', title:'Youth Islamic Program',   desc:'Weekly Islamic education and activities for children ages 6–16.',                                             date: nextDay(now,6), time:'10:00 AM', end:'12:00 PM', location:'ICH Classroom',             category:'community', featured:false },
    { id:'5', title:'Sisters Halaqa',          desc:'Monthly gathering for sisters — Quran recitation, Islamic discussions, and community bonding.',               date: new Date(now.getFullYear(), now.getMonth(), now.getDate()+10), time:'7:00 PM', end:'8:30 PM', location:'ICH Sisters Hall', category:'halaqa', featured:false },
  ].sort((a,b) => a.date - b.date);
})();

function fmtDate(d) {
  return d.toLocaleDateString('en-US', { weekday:'long', month:'long', day:'numeric', year:'numeric' });
}

function EventCard({ event, featured }) {
  const [hov, setHov] = React.useState(false);
  return (
    <div style={{
      background: featured ? `${ICH.primary}08` : '#fff',
      border:`1px solid ${hov ? ICH.primary+'55' : featured ? ICH.primary+'33' : ICH.border}`,
      borderRadius:6, padding:'20px 22px',
      boxShadow: hov ? '0 4px 16px rgba(27,94,32,.09)' : 'none',
      transition:'all .2s',
    }} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:12, marginBottom:10 }}>
        <h3 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:21, fontWeight:600, lineHeight:1.2, color:ICH.text }}>{event.title}</h3>
        <Tag color={CAT_COLORS[event.category] || 'gray'}>{event.category}</Tag>
      </div>
      <p style={{ fontSize:13, color:ICH.textMuted, lineHeight:1.65, marginBottom:14 }}>{event.desc}</p>
      <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
        {[
          ['📅', fmtDate(event.date)],
          ['🕐', `${event.time}${event.end ? ` – ${event.end}` : ''}`],
          ['📍', event.location],
        ].map(([icon, text]) => (
          <div key={icon} style={{ display:'flex', gap:8, alignItems:'center', fontSize:13, color:ICH.textMuted }}>
            <span style={{ fontSize:12, flexShrink:0 }}>{icon}</span>
            <span>{text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function EventsPage({ setPage }) {
  const [filter, setFilter] = React.useState('all');
  const categories = ['all', ...Array.from(new Set(SAMPLE_EVENTS.map(e => e.category)))];

  // FIX: featured events only shown in "Featured" section, not duplicated in "All Upcoming"
  const featured  = SAMPLE_EVENTS.filter(e => e.featured);
  const remaining = SAMPLE_EVENTS.filter(e => !e.featured);
  const displayed = filter === 'all' ? remaining : remaining.filter(e => e.category === filter);

  return (
    <div className="page-enter" style={{ maxWidth:900, margin:'0 auto', padding:'52px 24px 80px' }}>

      <div style={{ marginBottom:40 }}>
        <GoldLabel>Community Calendar</GoldLabel>
        <h1 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:'clamp(32px,5vw,52px)', fontWeight:600, marginBottom:10 }}>Events</h1>
        <p style={{ fontSize:16, color:ICH.textMuted }}>Upcoming programs, prayers, and community events at ICH</p>
      </div>

      {/* Featured events */}
      {featured.length > 0 && (
        <div style={{ marginBottom:44 }}>
          <div style={{ fontSize:11, fontWeight:700, letterSpacing:'.12em', textTransform:'uppercase', color:ICH.gold, fontFamily:'Inter,sans-serif', marginBottom:14, display:'flex', alignItems:'center', gap:10 }}>
            <span style={{ width:18, height:1.5, background:ICH.gold, display:'block' }}/> Featured Events <span style={{ width:18, height:1.5, background:ICH.gold, display:'block' }}/>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:14 }}>
            {featured.map(e => <EventCard key={e.id} event={e} featured/>)}
          </div>
        </div>
      )}

      {/* Category filter */}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:20 }}>
        {categories.map(cat => (
          <button key={cat} onClick={() => setFilter(cat)}
            style={{
              padding:'6px 14px', borderRadius:20, fontSize:12, fontWeight:600, cursor:'pointer', fontFamily:'Inter,sans-serif',
              background: filter===cat ? ICH.primary : '#fff',
              color: filter===cat ? '#fff' : ICH.textMuted,
              border:`1px solid ${filter===cat ? ICH.primary : ICH.border}`,
              textTransform:'capitalize', transition:'all .15s',
            }}
            onMouseEnter={e => { if(filter!==cat){ e.currentTarget.style.borderColor=ICH.primary; e.currentTarget.style.color=ICH.primary; }}}
            onMouseLeave={e => { if(filter!==cat){ e.currentTarget.style.borderColor=ICH.border; e.currentTarget.style.color=ICH.textMuted; }}}
          >{cat === 'all' ? 'All Events' : cat}</button>
        ))}
      </div>

      {/* All (non-featured) upcoming */}
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:'.12em', textTransform:'uppercase', color:ICH.textMuted, fontFamily:'Inter,sans-serif', marginBottom:14 }}>
        Upcoming Events
      </div>
      {displayed.length > 0 ? (
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {displayed.map(e => <EventCard key={e.id} event={e}/>)}
        </div>
      ) : (
        <div style={{ textAlign:'center', padding:'60px 0', color:ICH.textMuted }}>
          <div style={{ fontSize:40, marginBottom:12 }}>📅</div>
          <p style={{ fontSize:15 }}>No upcoming events in this category.</p>
        </div>
      )}

      {/* Suggest event */}
      <div style={{ marginTop:48, padding:24, background:ICH.bgCard, border:`1px solid ${ICH.border}`, borderRadius:6 }}>
        <h3 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:20, marginBottom:6 }}>Have an event to add?</h3>
        <p style={{ fontSize:13, color:ICH.textMuted, marginBottom:14, lineHeight:1.65 }}>Contact us to have your community event added to the ICH calendar.</p>
        <Btn variant="outline" onClick={() => { setPage('contact'); window.scrollTo(0,0); }} size="sm">Contact Us →</Btn>
      </div>
    </div>
  );
}

Object.assign(window, { PrayerTimesPage, EventsPage });
